@extends('layouts.app')
@section('content')
<user-edit-profile-form></user-edit-profile-form>

@endsection
