@extends('layouts.app')
@section('content')

<user-profile></user-profile>

@endsection
