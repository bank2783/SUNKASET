@extends('layouts.app')
@section('content')

    <home-view></home-view>

@endsection
