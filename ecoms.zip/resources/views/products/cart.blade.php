@extends('layouts.app')
@section('content')

<cart-view></cart-view>

@endsection
