<?php $__env->startSection('content'); ?>
<user-edit-profile-form></user-edit-profile-form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\Desktop\laravel_boost\ecoms\resources\views/Users/editprofile.blade.php ENDPATH**/ ?>