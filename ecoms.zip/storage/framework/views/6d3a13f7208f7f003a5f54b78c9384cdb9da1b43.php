<?php $__env->startSection('content'); ?>

<div class="container">
    <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">ชื่อสินค้า</th>
            <th scope="col">รายละเอียด</th>
            <th scope="col">ราคา</th>
            <th scope="col">จำนวน</th>
            <th scope="col">ชื่อร้านค้า</th>
            <th scope="col">แก้ไขสินค้า</th>
            <th scope="col">ลบสินค้าออกจากคลัง</th>

          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($row->id); ?></th>
            <td><?php echo e($row->product_name); ?></td>
            <td><?php echo e($row->product_detail); ?></td>
            <td><?php echo e($row->product_price); ?></td>
            <td><?php echo e($row->product_amount); ?></td>
            <td><?php echo e($row->market->market_name); ?></td>
            <td>
                <form action="<?php echo e(route('admin.warehouse.edit.product.form')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>

                    <input type="hidden" name="product_id" value="<?php echo e($row->id); ?>">
                    <button class="btn btn-warning" type="submit" >แก้ไข</button>
                </form>
            </td>
            <td>
                <form action="<?php echo e(route('admin.warehouse.delete.product')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>

                    <input type="hidden" name="product_id" value="<?php echo e($row->id); ?>">
                    <button class="btn btn-danger " type="submit" name="delete_product" value="delete">ลบ</button>
                </form>
            </td>


          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\Desktop\laravel_boost\ecoms\resources\views/Admin/warehouse.blade.php ENDPATH**/ ?>