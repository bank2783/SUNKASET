<?php $__env->startSection('content'); ?>

<product-view value="<?php echo e(Auth::user()->id); ?>" id="<?php echo e(request()->route('id')); ?>"></product-view>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\Desktop\laravel_boost\ecoms\resources\views/products/product_view.blade.php ENDPATH**/ ?>