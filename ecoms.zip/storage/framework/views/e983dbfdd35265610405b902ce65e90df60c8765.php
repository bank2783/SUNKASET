<?php $__env->startSection('content'); ?>

<div class="container">
    <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">ชื่อร้าน</th>
            <th scope="col">ที่อยู่</th>
            <th scope="col">เจ้าของร้าน</th>
            <th scope="col">อนุมัติ</th>
            <th scope="col">ไม่อนุมัติ</th>

          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $market_register; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($row->id); ?></th>
            <td><?php echo e($row->market_name); ?></td>
            <td><?php echo e($row->market_address); ?></td>
            <td><?php echo e($row->user->first_name); ?></td>
            <td>
                <form action="<?php echo e(route('admin.market.approved',$row->id)); ?>">
                    <button class="btn btn-success" type="submit" name="approved_bt" value="approved">อนุมัติ</button>
                </form>
            </td>
            <td><form action="<?php echo e(route('admin.market.no_approved',$row->id)); ?>">
                <button class="btn btn-danger" type="submit" name="no_approved_bt" value="no_approved">ไม่อนุมัติ</button>
            </form></td>

          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\Desktop\laravel_boost\ecoms\resources\views/Admin/approve.blade.php ENDPATH**/ ?>